"""Rule-based daily meal plan generator (no ML/AI).

10 static templates: 2 goals × 5 health conditions.
Each template is a dict with keys: Breakfast, Lunch, Dinner, Snack.
"""

from __future__ import annotations

from typing import Dict, List

from .exceptions import InvalidConditionError, InvalidGoalError

# ---------------------------------------------------------------------------
# Meal plan templates
# Structure: _PLANS[goal][condition] → {Breakfast, Lunch, Dinner, Snack}
# ---------------------------------------------------------------------------

_PLANS: Dict[str, Dict[str, Dict[str, str]]] = {
    # ===========================================================
    "Fat Cutting": {
    # ===========================================================
        "None": {
            "Breakfast": "Oatmeal with skimmed milk, topped with mixed berries",
            "Lunch":     "Grilled chicken breast salad with olive oil & lemon dressing",
            "Dinner":    "Baked salmon fillet with steamed broccoli and brown rice",
            "Snack":     "2 boiled eggs with a handful of almonds",
        },
        "Diabetes": {
            "Breakfast": "Steel-cut oats with cinnamon and a small handful of walnuts",
            "Lunch":     "Grilled turkey breast with a large leafy green salad and chickpeas",
            "Dinner":    "Baked cod with steamed green beans and cauliflower rice",
            "Snack":     "Celery sticks with a tablespoon of natural peanut butter",
        },
        "Hypertension": {
            "Breakfast": "Unsalted oats with banana slices and low-fat milk",
            "Lunch":     "Homemade grilled chicken wrap with lettuce (no added salt)",
            "Dinner":    "Baked salmon with garlic, spinach, and sweet potato",
            "Snack":     "A handful of unsalted mixed nuts and an apple",
        },
        "PCOS": {
            "Breakfast": "Quinoa porridge with berries and a sprinkle of flaxseeds",
            "Lunch":     "Grilled salmon with a large mixed-vegetable salad",
            "Dinner":    "Baked chicken thighs with roasted broccoli and brown rice",
            "Snack":     "A small apple with a tablespoon of almond butter",
        },
        "Celiac": {
            "Breakfast": "Certified gluten-free oats with banana and honey",
            "Lunch":     "Grilled chicken with quinoa salad and mixed vegetables",
            "Dinner":    "Baked tilapia with steamed rice and roasted courgette",
            "Snack":     "Rice cakes with avocado and a pinch of black pepper",
        },
    },
    # ===========================================================
    "Bulking": {
    # ===========================================================
        "None": {
            "Breakfast": "Oats with whole milk, banana, peanut butter, and 2 scrambled eggs",
            "Lunch":     "Chicken breast with white rice, black beans, and sweet corn",
            "Dinner":    "Beef mince pasta with tomato sauce and Parmesan",
            "Snack":     "Whole-grain peanut butter toast and a banana",
        },
        "Diabetes": {
            "Breakfast": "Low-GI muesli (no added sugar) with skimmed milk and a handful of berries",
            "Lunch":     "Grilled chicken with brown rice, lentils, and mixed greens",
            "Dinner":    "Lean beef stir-fry with broccoli, peppers, and brown rice noodles",
            "Snack":     "Cottage cheese with a small pear and a handful of walnuts",
        },
        "Hypertension": {
            "Breakfast": "Oats with banana and unsalted peanut butter, glass of low-fat milk",
            "Lunch":     "Grilled chicken with sweet potato mash and steamed spinach",
            "Dinner":    "Baked salmon with brown rice and garlic-sautéed kale (no salt)",
            "Snack":     "Unsalted peanut butter on a banana with low-fat yoghurt",
        },
        "PCOS": {
            "Breakfast": "Smoothie: spinach, banana, flaxseeds, almond milk, and protein powder",
            "Lunch":     "Brown rice bowl with grilled salmon, edamame, and roasted vegetables",
            "Dinner":    "Chicken breast with quinoa, roasted sweet potato, and broccoli",
            "Snack":     "Greek yoghurt with walnuts and a drizzle of honey",
        },
        "Celiac": {
            "Breakfast": "GF oats with whole milk, banana, and peanut butter",
            "Lunch":     "Grilled chicken with rice noodles, mixed vegetables, and tamari sauce",
            "Dinner":    "Beef and vegetable stew with potatoes (no thickener / GF only)",
            "Snack":     "GF bread with peanut butter and a glass of milk",
        },
    },
}


# ---------------------------------------------------------------------------
# Public function
# ---------------------------------------------------------------------------

def generate_plan(goal: str, conditions: List[str]) -> Dict[str, str]:
    """Return a daily meal plan dict for the given *goal* and *conditions*.

    When multiple conditions are selected the most restrictive one takes
    precedence (first non-'None' condition in the list).  Falls back to
    'None' if no specific condition is active.

    Returns
    -------
    Dict with keys: ``Breakfast``, ``Lunch``, ``Dinner``, ``Snack``

    Raises
    ------
    InvalidGoalError
        If *goal* is not recognised.
    InvalidConditionError
        If any condition in *conditions* is not recognised.
    """
    if goal not in _PLANS:
        raise InvalidGoalError(
            f"Unknown goal '{goal}'. Valid options: {list(_PLANS.keys())}"
        )

    goal_plans = _PLANS[goal]

    # Pick the primary condition: first non-"None" entry, or "None" if empty/all None
    primary_condition = "None"
    for cond in conditions:
        if cond not in goal_plans:
            raise InvalidConditionError(
                f"Unknown condition '{cond}'. Valid options: {list(goal_plans.keys())}"
            )
        if cond != "None":
            primary_condition = cond
            break

    return goal_plans[primary_condition]
