"""Unit tests for calculator.py"""

import pytest

from healthy_diet_app.calculator import (
    calculate_all,
    calculate_bmr,
    calculate_macros,
    calculate_target_calories,
    calculate_tdee,
)
from healthy_diet_app.exceptions import InvalidGoalError
from healthy_diet_app.models import UserProfile


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_profile(**kwargs) -> UserProfile:
    defaults = dict(
        age=25,
        gender="Male",
        weight_kg=75.0,
        height_cm=175.0,
        activity_level="Moderately Active",
        goal="Fat Cutting",
        health_conditions=["None"],
    )
    defaults.update(kwargs)
    return UserProfile(**defaults)


# ---------------------------------------------------------------------------
# BMR tests
# ---------------------------------------------------------------------------

class TestCalculateBMR:
    def test_male_bmr(self):
        """Male BMR: 10*75 + 6.25*175 - 5*25 + 5 = 750 + 1093.75 - 125 + 5 = 1723.75"""
        profile = _make_profile(gender="Male", weight_kg=75.0, height_cm=175.0, age=25)
        assert calculate_bmr(profile) == pytest.approx(1723.75, rel=1e-3)

    def test_female_bmr(self):
        """Female BMR: 10*60 + 6.25*165 - 5*30 - 161 = 600 + 1031.25 - 150 - 161 = 1320.25"""
        profile = _make_profile(gender="Female", weight_kg=60.0, height_cm=165.0, age=30)
        assert calculate_bmr(profile) == pytest.approx(1320.25, rel=1e-3)

    def test_bmr_increases_with_weight(self):
        p1 = _make_profile(weight_kg=70.0)
        p2 = _make_profile(weight_kg=90.0)
        assert calculate_bmr(p2) > calculate_bmr(p1)

    def test_bmr_decreases_with_age(self):
        p1 = _make_profile(age=20)
        p2 = _make_profile(age=60)
        assert calculate_bmr(p2) < calculate_bmr(p1)


# ---------------------------------------------------------------------------
# TDEE tests
# ---------------------------------------------------------------------------

class TestCalculateTDEE:
    def test_sedentary(self):
        assert calculate_tdee(1800.0, "Sedentary") == pytest.approx(2160.0, rel=1e-3)

    def test_lightly_active(self):
        assert calculate_tdee(1800.0, "Lightly Active") == pytest.approx(2475.0, rel=1e-3)

    def test_moderately_active(self):
        assert calculate_tdee(1800.0, "Moderately Active") == pytest.approx(2790.0, rel=1e-3)

    def test_very_active(self):
        assert calculate_tdee(1800.0, "Very Active") == pytest.approx(3105.0, rel=1e-3)

    def test_extra_active(self):
        assert calculate_tdee(1800.0, "Extra Active") == pytest.approx(3420.0, rel=1e-3)


# ---------------------------------------------------------------------------
# Target calorie tests
# ---------------------------------------------------------------------------

class TestCalculateTargetCalories:
    def test_fat_cutting_normal(self):
        target, clamped, _ = calculate_target_calories(2500.0, "Fat Cutting", "Male")
        assert target == pytest.approx(2000.0, rel=1e-3)
        assert clamped is False

    def test_bulking_normal(self):
        target, clamped, _ = calculate_target_calories(2500.0, "Bulking", "Male")
        assert target == pytest.approx(2900.0, rel=1e-3)
        assert clamped is False

    def test_fat_cutting_clamped_male(self):
        """Very low TDEE → cutting would go below 1500 kcal floor for male."""
        target, clamped, warning = calculate_target_calories(1800.0, "Fat Cutting", "Male")
        assert target == pytest.approx(1500.0, rel=1e-3)
        assert clamped is True
        assert "1500" in warning

    def test_fat_cutting_clamped_female(self):
        """Low TDEE → cutting would go below 1200 kcal floor for female."""
        target, clamped, warning = calculate_target_calories(1500.0, "Fat Cutting", "Female")
        assert target == pytest.approx(1200.0, rel=1e-3)
        assert clamped is True
        assert "1200" in warning

    def test_invalid_goal_raises(self):
        with pytest.raises(InvalidGoalError):
            calculate_target_calories(2000.0, "InvalidGoal", "Male")


# ---------------------------------------------------------------------------
# Macro breakdown tests
# ---------------------------------------------------------------------------

class TestCalculateMacros:
    def test_cutting_macros(self):
        """2000 kcal Cutting: protein=200g (40%), carbs=150g (30%), fats=66.7g (30%)"""
        macros = calculate_macros(2000.0, "Fat Cutting")
        assert macros["protein_g"] == pytest.approx(200.0, rel=1e-2)
        assert macros["carbs_g"]   == pytest.approx(150.0, rel=1e-2)
        assert macros["fats_g"]    == pytest.approx(66.7,  rel=1e-2)

    def test_bulking_macros(self):
        """2800 kcal Bulking: protein=210g (30%), carbs=350g (50%), fats=62.2g (20%)"""
        macros = calculate_macros(2800.0, "Bulking")
        assert macros["protein_g"] == pytest.approx(210.0, rel=1e-2)
        assert macros["carbs_g"]   == pytest.approx(350.0, rel=1e-2)
        assert macros["fats_g"]    == pytest.approx(62.2,  rel=1e-2)

    def test_invalid_goal_raises(self):
        with pytest.raises(InvalidGoalError):
            calculate_macros(2000.0, "WeirdGoal")


# ---------------------------------------------------------------------------
# calculate_all integration test
# ---------------------------------------------------------------------------

class TestCalculateAll:
    def test_returns_calorie_result(self):
        profile = _make_profile()
        result = calculate_all(profile)
        assert result.bmr > 0
        assert result.tdee > result.bmr
        assert result.protein_g > 0
        assert result.carbs_g > 0
        assert result.fats_g > 0
