"""Unit tests for meal_tracker.py"""

import pytest

from healthy_diet_app.exceptions import InvalidMealDataError
from healthy_diet_app.meal_tracker import add_meal, get_remaining, get_totals, remove_meal
from healthy_diet_app.models import DailyLog, Meal


def _make_meal(
    name: str = "Chicken",
    calories: float = 300.0,
    protein_g: float = 40.0,
    carbs_g: float = 10.0,
    fats_g: float = 8.0,
) -> Meal:
    return Meal(name=name, calories=calories, protein_g=protein_g,
                carbs_g=carbs_g, fats_g=fats_g)


class TestAddMeal:
    def test_add_valid_meal(self):
        log = DailyLog()
        add_meal(log, _make_meal())
        assert len(log.meals) == 1

    def test_totals_updated_after_add(self):
        log = DailyLog()
        add_meal(log, _make_meal(calories=300.0, protein_g=40.0, carbs_g=10.0, fats_g=8.0))
        add_meal(log, _make_meal(calories=200.0, protein_g=20.0, carbs_g=25.0, fats_g=5.0))
        totals = get_totals(log)
        assert totals["calories"]  == pytest.approx(500.0, rel=1e-3)
        assert totals["protein_g"] == pytest.approx(60.0,  rel=1e-3)
        assert totals["carbs_g"]   == pytest.approx(35.0,  rel=1e-3)
        assert totals["fats_g"]    == pytest.approx(13.0,  rel=1e-3)

    def test_zero_calorie_meal_allowed(self):
        """0-calorie items (e.g. black coffee, water) are valid."""
        log = DailyLog()
        add_meal(log, _make_meal(calories=0.0, protein_g=0.0, carbs_g=0.0, fats_g=0.0))
        assert len(log.meals) == 1

    def test_negative_calories_raises(self):
        log = DailyLog()
        with pytest.raises(InvalidMealDataError):
            add_meal(log, _make_meal(calories=-50.0))

    def test_negative_protein_raises(self):
        log = DailyLog()
        with pytest.raises(InvalidMealDataError):
            add_meal(log, _make_meal(protein_g=-5.0))

    def test_empty_name_raises(self):
        log = DailyLog()
        with pytest.raises(InvalidMealDataError):
            add_meal(log, _make_meal(name=""))

    def test_whitespace_name_raises(self):
        log = DailyLog()
        with pytest.raises(InvalidMealDataError):
            add_meal(log, _make_meal(name="   "))

    def test_excessive_calories_raises(self):
        log = DailyLog()
        with pytest.raises(InvalidMealDataError):
            add_meal(log, _make_meal(calories=6000.0))


class TestRemoveMeal:
    def test_remove_only_meal(self):
        log = DailyLog()
        add_meal(log, _make_meal())
        remove_meal(log, 0)
        assert len(log.meals) == 0

    def test_remove_first_of_two(self):
        log = DailyLog()
        add_meal(log, _make_meal(name="Meal A"))
        add_meal(log, _make_meal(name="Meal B"))
        remove_meal(log, 0)
        assert log.meals[0].name == "Meal B"

    def test_out_of_range_raises(self):
        log = DailyLog()
        with pytest.raises(IndexError):
            remove_meal(log, 0)

    def test_negative_index_raises(self):
        log = DailyLog()
        add_meal(log, _make_meal())
        with pytest.raises(IndexError):
            remove_meal(log, -1)


class TestGetTotals:
    def test_empty_log_returns_zeros(self):
        totals = get_totals(DailyLog())
        assert totals == {"calories": 0.0, "protein_g": 0.0, "carbs_g": 0.0, "fats_g": 0.0}


class TestGetRemaining:
    def test_under_target(self):
        log = DailyLog()
        add_meal(log, _make_meal(calories=300.0))
        assert get_remaining(log, 2000.0) == pytest.approx(1700.0, rel=1e-3)

    def test_over_target_returns_negative(self):
        log = DailyLog()
        add_meal(log, _make_meal(calories=2500.0))
        remaining = get_remaining(log, 2000.0)
        assert remaining < 0
        assert remaining == pytest.approx(-500.0, rel=1e-3)
