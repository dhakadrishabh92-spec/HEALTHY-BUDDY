"""Unit tests for diet_advisor.py"""

import pytest

from healthy_diet_app.diet_advisor import get_combined_restrictions, get_restrictions, get_safe_foods
from healthy_diet_app.exceptions import InvalidConditionError


class TestGetRestrictions:
    def test_diabetes_avoid_contains_sugary_drinks(self):
        rules = get_restrictions("Diabetes")
        assert any("sugary" in item.lower() or "sugar" in item.lower() for item in rules["avoid"])

    def test_diabetes_has_all_keys(self):
        rules = get_restrictions("Diabetes")
        assert set(rules.keys()) == {"avoid", "prefer", "tips"}

    def test_hypertension_tips_mention_sodium(self):
        rules = get_restrictions("Hypertension")
        combined = " ".join(rules["tips"]).lower()
        assert "sodium" in combined

    def test_pcos_prefer_contains_anti_inflammatory(self):
        rules = get_restrictions("PCOS")
        combined = " ".join(rules["prefer"]).lower()
        assert "anti-inflammatory" in combined or "omega" in combined

    def test_celiac_avoid_contains_wheat(self):
        rules = get_restrictions("Celiac")
        assert any("wheat" in item.lower() for item in rules["avoid"])

    def test_none_avoid_is_empty(self):
        rules = get_restrictions("None")
        assert rules["avoid"] == []

    def test_unknown_condition_raises(self):
        with pytest.raises(InvalidConditionError):
            get_restrictions("UnknownCondition")


class TestGetSafeFoods:
    def test_returns_list(self):
        foods = get_safe_foods("Diabetes")
        assert isinstance(foods, list)
        assert len(foods) > 0

    def test_none_returns_list(self):
        foods = get_safe_foods("None")
        assert isinstance(foods, list)

    def test_invalid_raises(self):
        with pytest.raises(InvalidConditionError):
            get_safe_foods("XYZ")


class TestGetCombinedRestrictions:
    def test_single_condition(self):
        result = get_combined_restrictions(["Diabetes"])
        assert "avoid" in result
        assert len(result["avoid"]) > 0

    def test_none_condition(self):
        result = get_combined_restrictions(["None"])
        assert result["avoid"] == []

    def test_multiple_conditions_merged(self):
        result = get_combined_restrictions(["Diabetes", "Hypertension"])
        # Should have items from both conditions
        assert len(result["avoid"]) > len(get_restrictions("Diabetes")["avoid"]) or \
               len(result["avoid"]) >= len(get_restrictions("Diabetes")["avoid"])

    def test_no_duplicates_in_merged(self):
        result = get_combined_restrictions(["Celiac", "Celiac"])
        avoid_set = set(result["avoid"])
        assert len(result["avoid"]) == len(avoid_set)
