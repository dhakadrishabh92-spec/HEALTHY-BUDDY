"""Unit tests for meal_plan.py"""

import pytest

from healthy_diet_app.exceptions import InvalidConditionError, InvalidGoalError
from healthy_diet_app.meal_plan import generate_plan

_EXPECTED_KEYS = {"Breakfast", "Lunch", "Dinner", "Snack"}


class TestGeneratePlan:
    # All 10 goal × condition combinations
    def test_cutting_none(self):
        plan = generate_plan("Fat Cutting", ["None"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_cutting_diabetes(self):
        plan = generate_plan("Fat Cutting", ["Diabetes"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_cutting_hypertension(self):
        plan = generate_plan("Fat Cutting", ["Hypertension"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_cutting_pcos(self):
        plan = generate_plan("Fat Cutting", ["PCOS"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_cutting_celiac(self):
        plan = generate_plan("Fat Cutting", ["Celiac"])
        assert set(plan.keys()) == _EXPECTED_KEYS
        # Celiac plan must not mention gluten items
        full_text = " ".join(plan.values()).lower()
        assert "wheat" not in full_text
        assert "barley" not in full_text

    def test_bulking_none(self):
        plan = generate_plan("Bulking", ["None"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_bulking_diabetes(self):
        plan = generate_plan("Bulking", ["Diabetes"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_bulking_hypertension(self):
        plan = generate_plan("Bulking", ["Hypertension"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_bulking_pcos(self):
        plan = generate_plan("Bulking", ["PCOS"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    def test_bulking_celiac(self):
        plan = generate_plan("Bulking", ["Celiac"])
        assert set(plan.keys()) == _EXPECTED_KEYS

    # Plan values are non-empty strings
    def test_plan_values_are_strings(self):
        plan = generate_plan("Bulking", ["None"])
        for slot, desc in plan.items():
            assert isinstance(desc, str), f"{slot} should be a string"
            assert len(desc) > 0, f"{slot} should not be empty"

    # Fallback to None when conditions list contains only None
    def test_conditions_none_list_uses_default(self):
        plan_none = generate_plan("Fat Cutting", ["None"])
        plan_empty_fallback = generate_plan("Fat Cutting", ["None"])
        assert plan_none == plan_empty_fallback

    # Multiple conditions: first non-None is used
    def test_first_non_none_condition_wins(self):
        plan_diab = generate_plan("Fat Cutting", ["Diabetes"])
        plan_multi = generate_plan("Fat Cutting", ["Diabetes", "Celiac"])
        assert plan_diab == plan_multi

    # Invalid inputs
    def test_invalid_goal_raises(self):
        with pytest.raises(InvalidGoalError):
            generate_plan("Maintain", ["None"])

    def test_invalid_condition_raises(self):
        with pytest.raises(InvalidConditionError):
            generate_plan("Bulking", ["Keto"])
