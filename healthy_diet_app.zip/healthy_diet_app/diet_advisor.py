"""Health condition dietary advice (rule-based lookup — no ML/AI)."""

from __future__ import annotations

from typing import Dict, List

from .exceptions import InvalidConditionError

# ---------------------------------------------------------------------------
# Condition data store
# Each entry has: avoid, prefer, tips
# ---------------------------------------------------------------------------

_CONDITION_RULES: Dict[str, Dict[str, List[str]]] = {
    "None": {
        "avoid": [],
        "prefer": [
            "Whole grains",
            "Lean proteins (chicken, fish, eggs)",
            "Fresh fruits and vegetables",
            "Low-fat dairy",
            "Nuts and seeds",
        ],
        "tips": [
            "Drink at least 8 glasses of water per day.",
            "Aim for 5 servings of fruits and vegetables daily.",
            "Limit ultra-processed and packaged foods.",
            "Eat regular meals — avoid skipping breakfast.",
        ],
    },
    "Diabetes": {
        "avoid": [
            "Sugary drinks (soda, fruit juice, energy drinks)",
            "White rice and white bread",
            "Candy and sweets",
            "Pastries and cakes",
            "Sweetened cereals",
            "High-GI fruits (watermelon, ripe banana in large portions)",
        ],
        "prefer": [
            "Leafy greens (spinach, kale, broccoli)",
            "Legumes (lentils, chickpeas, black beans)",
            "Whole grains (brown rice, oats, quinoa)",
            "Nuts and seeds",
            "Berries (strawberries, blueberries)",
            "Lean proteins (chicken, turkey, tofu)",
            "Low-fat dairy",
        ],
        "tips": [
            "Choose low-GI foods to keep blood sugar stable.",
            "Eat smaller, more frequent meals throughout the day.",
            "Count carbohydrates — aim for consistent portions.",
            "Avoid skipping meals, which can cause blood sugar swings.",
            "Combine carbs with protein or healthy fats to slow glucose absorption.",
        ],
    },
    "Hypertension": {
        "avoid": [
            "Table salt and salty seasonings",
            "Processed and cured meats (bacon, sausage, deli meats)",
            "Canned soups and sauces",
            "Pickled foods",
            "Fast food and takeaways",
            "Full-fat dairy (butter, cream cheese)",
            "Alcohol",
        ],
        "prefer": [
            "Potassium-rich foods (banana, spinach, sweet potato)",
            "Oats and whole grains",
            "Garlic and herbs (natural flavour without salt)",
            "Olive oil (instead of butter)",
            "Fatty fish (salmon, mackerel — omega-3s)",
            "Low-fat dairy (potassium + calcium)",
            "Berries and dark leafy greens",
        ],
        "tips": [
            "Limit sodium to under 1,500 mg per day.",
            "Use herbs, lemon juice, or vinegar instead of salt.",
            "Follow the DASH diet principles.",
            "Stay well hydrated throughout the day.",
            "Avoid alcohol — it raises blood pressure.",
        ],
    },
    "PCOS": {
        "avoid": [
            "Refined carbohydrates (white bread, white pasta, pastries)",
            "Sugary snacks and desserts",
            "Trans fats (margarine, fried fast food)",
            "Excessive dairy (full-fat cheese, cream)",
            "Red and processed meats",
            "Sweetened beverages",
        ],
        "prefer": [
            "Anti-inflammatory foods (turmeric, ginger, berries)",
            "High-fibre vegetables (broccoli, Brussels sprouts, carrots)",
            "Whole grains (oats, quinoa, brown rice)",
            "Lean proteins (chicken, eggs, legumes)",
            "Omega-3-rich foods (salmon, walnuts, flaxseeds)",
            "Low-GI fruits (apples, pears, cherries)",
        ],
        "tips": [
            "Eat low-GI foods to manage insulin resistance.",
            "Include omega-3 fatty acids to reduce inflammation.",
            "Aim for consistent meal timing to stabilise blood sugar.",
            "Limit added sugars in all forms.",
            "High-fibre foods help reduce androgen levels.",
        ],
    },
    "Celiac": {
        "avoid": [
            "Wheat (bread, pasta, couscous, spelt, semolina)",
            "Barley (including malt, beer)",
            "Rye",
            "Regular oats (unless certified gluten-free)",
            "Soy sauce (contains wheat)",
            "Most commercial baked goods",
            "Many processed sauces and gravies",
        ],
        "prefer": [
            "Rice and rice noodles",
            "Quinoa",
            "Corn and polenta",
            "Potatoes and sweet potatoes",
            "Certified gluten-free oats",
            "Legumes (beans, lentils, chickpeas)",
            "Fresh fruits, vegetables, and unprocessed meats",
            "Gluten-free bread and pasta (labelled certified GF)",
        ],
        "tips": [
            "Always read food labels — 'wheat-free' does not mean gluten-free.",
            "Avoid cross-contamination: use separate utensils and cookware.",
            "Supplement vitamins B12, D, iron, and folate (often deficient).",
            "Eat naturally gluten-free whole foods as the foundation of your diet.",
            "Inform restaurants about your condition when eating out.",
        ],
    },
}

VALID_CONDITIONS: tuple[str, ...] = tuple(_CONDITION_RULES.keys())


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

def get_restrictions(condition: str) -> Dict[str, List[str]]:
    """Return a dict with keys 'avoid', 'prefer', 'tips' for *condition*.

    Raises
    ------
    InvalidConditionError
        If *condition* is not a recognised health condition.
    """
    _validate_condition(condition)
    return _CONDITION_RULES[condition]


def get_safe_foods(condition: str) -> List[str]:
    """Return a flat list of preferred / safe foods for *condition*.

    Raises
    ------
    InvalidConditionError
        If *condition* is not a recognised health condition.
    """
    _validate_condition(condition)
    return _CONDITION_RULES[condition]["prefer"]


def get_combined_restrictions(conditions: List[str]) -> Dict[str, List[str]]:
    """Merge restrictions for multiple conditions into one combined dict.

    Deduplicates items within each list.  Returns keys: 'avoid', 'prefer', 'tips'.
    """
    combined: Dict[str, List[str]] = {"avoid": [], "prefer": [], "tips": []}
    for condition in conditions:
        rules = get_restrictions(condition)
        for key in combined:
            for item in rules[key]:
                if item not in combined[key]:
                    combined[key].append(item)
    return combined


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _validate_condition(condition: str) -> None:
    if condition not in _CONDITION_RULES:
        raise InvalidConditionError(
            f"Unknown condition '{condition}'. "
            f"Valid options: {list(_CONDITION_RULES.keys())}"
        )
