"""Meal tracking — add, remove, and summarise meals in a DailyLog."""

from __future__ import annotations

from typing import Dict

from .exceptions import InvalidMealDataError
from .models import DailyLog, Meal

# Validation limits
_MAX_MEAL_CALORIES: float = 5000.0
_MAX_MACRO_G: float = 500.0


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

def add_meal(log: DailyLog, meal: Meal) -> None:
    """Validate *meal* then append it to *log*.

    Raises
    ------
    InvalidMealDataError
        If any nutritional value is negative or exceeds its maximum.
    """
    _validate_meal(meal)
    log.meals.append(meal)


def remove_meal(log: DailyLog, index: int) -> None:
    """Remove the meal at *index* from *log*.

    Raises
    ------
    IndexError
        If *index* is out of range.
    """
    if index < 0 or index >= len(log.meals):
        raise IndexError(
            f"Meal index {index} is out of range. Log has {len(log.meals)} meal(s)."
        )
    log.meals.pop(index)


def get_totals(log: DailyLog) -> Dict[str, float]:
    """Return a dict of summed nutritional values for all meals in *log*.

    Keys: ``calories``, ``protein_g``, ``carbs_g``, ``fats_g``
    """
    return {
        "calories":  log.total_calories,
        "protein_g": log.total_protein_g,
        "carbs_g":   log.total_carbs_g,
        "fats_g":    log.total_fats_g,
    }


def get_remaining(log: DailyLog, target_calories: float) -> float:
    """Return how many kcal remain before the daily target is reached.

    A negative value means the user is over their target.
    """
    return round(target_calories - log.total_calories, 2)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _validate_meal(meal: Meal) -> None:
    """Raise InvalidMealDataError if any field is out of acceptable range."""
    if not meal.name or not meal.name.strip():
        raise InvalidMealDataError("Meal name cannot be empty.")
    if len(meal.name) > 100:
        raise InvalidMealDataError("Meal name must be 100 characters or fewer.")

    if meal.calories < 0:
        raise InvalidMealDataError("Calories cannot be negative.")
    if meal.calories > _MAX_MEAL_CALORIES:
        raise InvalidMealDataError(
            f"Calories per meal cannot exceed {_MAX_MEAL_CALORIES} kcal."
        )

    for field_name, value in [
        ("protein_g", meal.protein_g),
        ("carbs_g", meal.carbs_g),
        ("fats_g", meal.fats_g),
    ]:
        if value < 0:
            raise InvalidMealDataError(f"{field_name} cannot be negative.")
        if value > _MAX_MACRO_G:
            raise InvalidMealDataError(
                f"{field_name} cannot exceed {_MAX_MACRO_G} g per meal."
            )
