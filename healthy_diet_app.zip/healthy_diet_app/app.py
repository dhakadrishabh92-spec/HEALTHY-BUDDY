"""Streamlit UI — entry point for the Healthy Diet Management App.

All business logic lives in the other modules.
This file only handles layout, widgets, and session state.
"""

from __future__ import annotations

import sys
import os

# Allow running as: streamlit run healthy_diet_app/app.py
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

from healthy_diet_app.calculator import calculate_all
from healthy_diet_app.diet_advisor import get_combined_restrictions
from healthy_diet_app.meal_plan import generate_plan
from healthy_diet_app.meal_tracker import add_meal, get_remaining, get_totals, remove_meal
from healthy_diet_app.models import (
    VALID_ACTIVITY_LEVELS,
    VALID_CONDITIONS,
    VALID_GENDERS,
    VALID_GOALS,
    DailyLog,
    Meal,
    UserProfile,
)
from healthy_diet_app.storage import load_session, save_session


# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="🥗 Healthy Diet Management",
    page_icon="🥗",
    layout="centered",
)


# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------

def _init_state() -> None:
    """Load persisted session or set defaults on first run."""
    if "initialised" not in st.session_state:
        profile, log = load_session()
        st.session_state.profile = profile
        st.session_state.log = log
        st.session_state.result = calculate_all(profile) if profile else None
        st.session_state.initialised = True


_init_state()


# ---------------------------------------------------------------------------
# Page header
# ---------------------------------------------------------------------------

st.title("🥗 Healthy Diet Management App")
st.markdown(
    "Track your daily calories and macros, get personalised diet advice, "
    "and follow a simple meal plan — all in one place."
)
st.divider()


# ---------------------------------------------------------------------------
# Section 1 — Personal Profile
# ---------------------------------------------------------------------------

with st.expander("📋 Section 1: Personal Profile", expanded=st.session_state.profile is None):
    with st.form("profile_form"):
        col1, col2 = st.columns(2)

        with col1:
            age = st.number_input("Age (years)", min_value=10, max_value=100, value=25, step=1)
            weight = st.number_input("Weight (kg)", min_value=20.0, max_value=300.0, value=70.0, step=0.5)
            activity = st.selectbox("Activity Level", VALID_ACTIVITY_LEVELS, index=2)

        with col2:
            gender = st.selectbox("Gender", VALID_GENDERS)
            height = st.number_input("Height (cm)", min_value=100.0, max_value=250.0, value=170.0, step=0.5)
            goal = st.selectbox("Goal", VALID_GOALS)

        # Health conditions — multi-select; "None" is exclusive
        conditions_options = list(VALID_CONDITIONS)
        conditions = st.multiselect(
            "Health Conditions (select all that apply)",
            options=conditions_options,
            default=["None"],
            help='Select "None" if you have no specific health conditions.',
        )

        submitted = st.form_submit_button("💾 Save Profile", use_container_width=True)

    if submitted:
        # If user selects "None" alongside other conditions, keep only the others
        if "None" in conditions and len(conditions) > 1:
            conditions = [c for c in conditions if c != "None"]
        if not conditions:
            conditions = ["None"]

        new_profile = UserProfile(
            age=int(age),
            gender=gender,
            weight_kg=float(weight),
            height_cm=float(height),
            activity_level=activity,
            goal=goal,
            health_conditions=conditions,
        )
        valid, reason = new_profile.is_valid()
        if not valid:
            st.error(f"❌ {reason}")
        else:
            st.session_state.profile = new_profile
            st.session_state.result = calculate_all(new_profile)
            save_session(new_profile, st.session_state.log)
            st.success("✅ Profile saved!")
            st.rerun()


# ---------------------------------------------------------------------------
# Sections 2–6 are only shown once a profile exists
# ---------------------------------------------------------------------------

if st.session_state.profile is None:
    st.info("👆 Fill in your profile above to get started.")
    st.stop()

profile: UserProfile = st.session_state.profile
result = st.session_state.result
log: DailyLog = st.session_state.log


# ---------------------------------------------------------------------------
# Section 2 — Daily Targets
# ---------------------------------------------------------------------------

with st.expander("🔥 Section 2: Your Daily Targets", expanded=True):
    if result.clamped:
        st.warning(f"⚠️ {result.clamp_warning}")

    col1, col2, col3 = st.columns(3)
    col1.metric("BMR", f"{result.bmr:.0f} kcal", help="Basal Metabolic Rate — calories burned at rest")
    col2.metric("TDEE", f"{result.tdee:.0f} kcal", help="Total Daily Energy Expenditure")
    col3.metric("Daily Target", f"{result.target_calories:.0f} kcal",
                delta=f"{'−500' if profile.goal == 'Fat Cutting' else '+400'} kcal vs TDEE")

    st.markdown("#### 🧮 Macro Breakdown")
    macro_col1, macro_col2, macro_col3 = st.columns(3)
    macro_col1.metric("Protein", f"{result.protein_g:.0f} g",
                      help="40% of target for Cutting / 30% for Bulking")
    macro_col2.metric("Carbs", f"{result.carbs_g:.0f} g",
                      help="30% of target for Cutting / 50% for Bulking")
    macro_col3.metric("Fats", f"{result.fats_g:.0f} g",
                      help="30% of target for Cutting / 20% for Bulking")

    goal_badge = "🔴 Fat Cutting (−500 kcal deficit)" if profile.goal == "Fat Cutting" \
        else "🟢 Bulking (+400 kcal surplus)"
    st.caption(f"**Goal:** {goal_badge}  |  **Activity:** {profile.activity_level}")


# ---------------------------------------------------------------------------
# Section 3 — Log a Meal
# ---------------------------------------------------------------------------

with st.expander("➕ Section 3: Log a Meal", expanded=False):
    with st.form("meal_form", clear_on_submit=True):
        meal_name = st.text_input("Meal / Food Name", placeholder="e.g. Grilled Chicken Breast")

        m_col1, m_col2, m_col3, m_col4 = st.columns(4)
        meal_cal  = m_col1.number_input("Calories (kcal)", min_value=0.0, max_value=5000.0, value=0.0, step=10.0)
        meal_prot = m_col2.number_input("Protein (g)",     min_value=0.0, max_value=500.0,  value=0.0, step=1.0)
        meal_carb = m_col3.number_input("Carbs (g)",       min_value=0.0, max_value=500.0,  value=0.0, step=1.0)
        meal_fat  = m_col4.number_input("Fats (g)",        min_value=0.0, max_value=500.0,  value=0.0, step=1.0)

        add_btn = st.form_submit_button("➕ Add Meal", use_container_width=True)

    if add_btn:
        if not meal_name.strip():
            st.error("❌ Please enter a meal name.")
        else:
            try:
                new_meal = Meal(
                    name=meal_name.strip(),
                    calories=meal_cal,
                    protein_g=meal_prot,
                    carbs_g=meal_carb,
                    fats_g=meal_fat,
                )
                add_meal(log, new_meal)
                save_session(profile, log)
                st.success(f"✅ '{meal_name.strip()}' added!")
                st.rerun()
            except Exception as exc:
                st.error(f"❌ {exc}")


# ---------------------------------------------------------------------------
# Section 4 — Today's Intake
# ---------------------------------------------------------------------------

with st.expander("📊 Section 4: Today's Intake", expanded=True):
    if not log.meals:
        st.info("No meals logged yet. Add your first meal above.")
    else:
        # Meal table with remove buttons
        st.markdown("#### Logged Meals")
        for i, meal in enumerate(log.meals):
            r_col1, r_col2 = st.columns([5, 1])
            with r_col1:
                st.write(
                    f"**{meal.name}** — "
                    f"{meal.calories:.0f} kcal | "
                    f"P: {meal.protein_g:.0f}g | "
                    f"C: {meal.carbs_g:.0f}g | "
                    f"F: {meal.fats_g:.0f}g"
                )
            with r_col2:
                if st.button("🗑️", key=f"del_{i}", help="Remove this meal"):
                    remove_meal(log, i)
                    save_session(profile, log)
                    st.rerun()

        st.divider()

        # Totals and progress
        totals = get_totals(log)
        remaining = get_remaining(log, result.target_calories)

        st.markdown("#### Daily Progress")

        # Calories progress bar
        cal_pct = min(totals["calories"] / result.target_calories, 1.0) if result.target_calories > 0 else 0.0
        st.markdown(f"**Calories:** {totals['calories']:.0f} / {result.target_calories:.0f} kcal")
        st.progress(cal_pct)

        if remaining >= 0:
            st.success(f"✅ {remaining:.0f} kcal remaining today")
        else:
            st.error(f"⚠️ {abs(remaining):.0f} kcal over target today")

        # Macro progress bars
        st.markdown("---")
        p_pct = min(totals["protein_g"] / result.protein_g, 1.0) if result.protein_g > 0 else 0.0
        c_pct = min(totals["carbs_g"]   / result.carbs_g,   1.0) if result.carbs_g   > 0 else 0.0
        f_pct = min(totals["fats_g"]    / result.fats_g,    1.0) if result.fats_g    > 0 else 0.0

        st.markdown(f"**Protein:** {totals['protein_g']:.0f} / {result.protein_g:.0f} g")
        st.progress(p_pct)
        st.markdown(f"**Carbs:** {totals['carbs_g']:.0f} / {result.carbs_g:.0f} g")
        st.progress(c_pct)
        st.markdown(f"**Fats:** {totals['fats_g']:.0f} / {result.fats_g:.0f} g")
        st.progress(f_pct)

        # Summary table
        st.markdown("---")
        st.markdown("#### Summary Table")
        summary_data = {
            "Nutrient":  ["Calories (kcal)", "Protein (g)", "Carbs (g)", "Fats (g)"],
            "Consumed":  [f"{totals['calories']:.0f}", f"{totals['protein_g']:.0f}",
                          f"{totals['carbs_g']:.0f}",  f"{totals['fats_g']:.0f}"],
            "Target":    [f"{result.target_calories:.0f}", f"{result.protein_g:.0f}",
                          f"{result.carbs_g:.0f}",         f"{result.fats_g:.0f}"],
            "Remaining": [f"{max(result.target_calories - totals['calories'], 0):.0f}",
                          f"{max(result.protein_g - totals['protein_g'], 0):.0f}",
                          f"{max(result.carbs_g   - totals['carbs_g'],   0):.0f}",
                          f"{max(result.fats_g    - totals['fats_g'],    0):.0f}"],
        }
        st.table(summary_data)


# ---------------------------------------------------------------------------
# Section 5 — Diet Advice
# ---------------------------------------------------------------------------

with st.expander("🥦 Section 5: Diet Advice Based on Your Health Conditions", expanded=False):
    active_conditions = profile.health_conditions or ["None"]
    rules = get_combined_restrictions(active_conditions)

    conditions_display = ", ".join(active_conditions)
    st.markdown(f"**Active conditions:** {conditions_display}")

    if rules["avoid"]:
        st.markdown("#### 🚫 Foods to Avoid")
        for item in rules["avoid"]:
            st.markdown(f"- {item}")

    st.markdown("#### ✅ Preferred Foods")
    for item in rules["prefer"]:
        st.markdown(f"- {item}")

    st.markdown("#### 💡 Tips")
    for tip in rules["tips"]:
        st.markdown(f"- {tip}")


# ---------------------------------------------------------------------------
# Section 6 — Suggested Meal Plan
# ---------------------------------------------------------------------------

with st.expander("🍽️ Section 6: Suggested Meal Plan for Today", expanded=False):
    active_conditions = profile.health_conditions or ["None"]
    try:
        plan = generate_plan(profile.goal, active_conditions)
        for slot, description in plan.items():
            slot_icons = {
                "Breakfast": "🌅",
                "Lunch":     "☀️",
                "Dinner":    "🌙",
                "Snack":     "🍎",
            }
            icon = slot_icons.get(slot, "🍴")
            st.markdown(f"**{icon} {slot}**")
            st.write(description)
            st.markdown("")
    except Exception as exc:
        st.error(f"Could not generate meal plan: {exc}")

st.divider()
st.caption(
    f"👤 Profile: {profile.age}y | {profile.gender} | {profile.weight_kg}kg | "
    f"{profile.height_cm}cm | {profile.activity_level} | Goal: {profile.goal}"
)
