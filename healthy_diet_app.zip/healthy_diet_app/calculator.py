"""Calorie and macro calculation logic (pure Python — no Streamlit dependency)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from .exceptions import InvalidGoalError
from .models import UserProfile

# ---------------------------------------------------------------------------
# Activity multiplier lookup
# ---------------------------------------------------------------------------

_ACTIVITY_MULTIPLIERS: Dict[str, float] = {
    "Sedentary": 1.2,
    "Lightly Active": 1.375,
    "Moderately Active": 1.55,
    "Very Active": 1.725,
    "Extra Active": 1.9,
}

# Minimum safe daily calories (kcal)
_MIN_CALORIES: Dict[str, float] = {
    "Male": 1500.0,
    "Female": 1200.0,
}

# Goal calorie adjustments (kcal)
_GOAL_ADJUSTMENT: Dict[str, float] = {
    "Fat Cutting": -500.0,
    "Bulking": +400.0,
}

# Macro ratios: {goal: {macro: fraction}}
_MACRO_RATIOS: Dict[str, Dict[str, float]] = {
    "Fat Cutting": {"protein": 0.40, "carbs": 0.30, "fats": 0.30},
    "Bulking":     {"protein": 0.30, "carbs": 0.50, "fats": 0.20},
}

# kcal per gram for each macro
_KCAL_PER_G: Dict[str, float] = {"protein": 4.0, "carbs": 4.0, "fats": 9.0}


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class CalorieResult:
    """Container for all calculated calorie and macro values."""

    bmr: float
    tdee: float
    target_calories: float
    protein_g: float
    carbs_g: float
    fats_g: float
    clamped: bool          # True if target was raised to the safe minimum
    clamp_warning: str     # Human-readable warning when clamped


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

def calculate_bmr(profile: UserProfile) -> float:
    """Return BMR (kcal/day) using the Mifflin-St Jeor equation.

    Male  : BMR = 10·w + 6.25·h − 5·age + 5
    Female: BMR = 10·w + 6.25·h − 5·age − 161
    """
    base = (10.0 * profile.weight_kg
            + 6.25 * profile.height_cm
            - 5.0 * profile.age)
    bmr = base + 5.0 if profile.gender == "Male" else base - 161.0
    return round(bmr, 2)


def calculate_tdee(bmr: float, activity_level: str) -> float:
    """Return TDEE (kcal/day) by multiplying BMR by the activity factor."""
    multiplier = _ACTIVITY_MULTIPLIERS.get(activity_level, 1.2)
    return round(bmr * multiplier, 2)


def calculate_target_calories(
    tdee: float,
    goal: str,
    gender: str,
) -> tuple[float, bool, str]:
    """Return (target_kcal, clamped, warning_message).

    Applies goal adjustment then clamps to the gender-specific safe minimum.

    Raises
    ------
    InvalidGoalError
        If *goal* is not a recognised goal string.
    """
    if goal not in _GOAL_ADJUSTMENT:
        raise InvalidGoalError(
            f"Unknown goal '{goal}'. Valid options: {list(_GOAL_ADJUSTMENT.keys())}"
        )

    raw_target = tdee + _GOAL_ADJUSTMENT[goal]
    floor = _MIN_CALORIES.get(gender, 1200.0)

    if raw_target < floor:
        return (
            round(floor, 2),
            True,
            f"Calculated target ({raw_target:.0f} kcal) was below the safe minimum "
            f"for {gender} ({floor:.0f} kcal). Target has been raised to {floor:.0f} kcal.",
        )

    return round(raw_target, 2), False, ""


def calculate_macros(
    target_calories: float,
    goal: str,
) -> Dict[str, float]:
    """Return macro breakdown in grams for the given goal.

    Returns
    -------
    dict with keys: ``protein_g``, ``carbs_g``, ``fats_g``

    Raises
    ------
    InvalidGoalError
        If *goal* is not a recognised goal string.
    """
    if goal not in _MACRO_RATIOS:
        raise InvalidGoalError(
            f"Unknown goal '{goal}'. Valid options: {list(_MACRO_RATIOS.keys())}"
        )

    ratios = _MACRO_RATIOS[goal]
    return {
        "protein_g": round((target_calories * ratios["protein"]) / _KCAL_PER_G["protein"], 1),
        "carbs_g":   round((target_calories * ratios["carbs"])   / _KCAL_PER_G["carbs"], 1),
        "fats_g":    round((target_calories * ratios["fats"])    / _KCAL_PER_G["fats"], 1),
    }


def calculate_all(profile: UserProfile) -> CalorieResult:
    """Convenience function — runs the full pipeline for a UserProfile.

    Returns a fully populated :class:`CalorieResult`.
    """
    bmr = calculate_bmr(profile)
    tdee = calculate_tdee(bmr, profile.activity_level)
    target, clamped, warning = calculate_target_calories(tdee, profile.goal, profile.gender)
    macros = calculate_macros(target, profile.goal)

    return CalorieResult(
        bmr=bmr,
        tdee=tdee,
        target_calories=target,
        protein_g=macros["protein_g"],
        carbs_g=macros["carbs_g"],
        fats_g=macros["fats_g"],
        clamped=clamped,
        clamp_warning=warning,
    )
