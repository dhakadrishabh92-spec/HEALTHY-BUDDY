"""Data models for the Healthy Diet Management App."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VALID_GENDERS: tuple[str, ...] = ("Male", "Female")
VALID_ACTIVITY_LEVELS: tuple[str, ...] = (
    "Sedentary",
    "Lightly Active",
    "Moderately Active",
    "Very Active",
    "Extra Active",
)
VALID_GOALS: tuple[str, ...] = ("Fat Cutting", "Bulking")
VALID_CONDITIONS: tuple[str, ...] = (
    "None",
    "Diabetes",
    "Hypertension",
    "PCOS",
    "Celiac",
)


# ---------------------------------------------------------------------------
# UserProfile
# ---------------------------------------------------------------------------

@dataclass
class UserProfile:
    """Stores personal information entered by the user."""

    age: int
    gender: str          # "Male" | "Female"
    weight_kg: float
    height_cm: float
    activity_level: str  # one of VALID_ACTIVITY_LEVELS
    goal: str            # "Fat Cutting" | "Bulking"
    health_conditions: List[str]  # subset of VALID_CONDITIONS

    def is_valid(self) -> tuple[bool, str]:
        """Return (True, '') if valid, or (False, reason) if not.

        Validation rules
        ----------------
        age          : 10 – 100
        weight_kg    : 20 – 300
        height_cm    : 100 – 250
        gender       : must be in VALID_GENDERS
        activity_level: must be in VALID_ACTIVITY_LEVELS
        goal         : must be in VALID_GOALS
        health_conditions: each element in VALID_CONDITIONS
        """
        if not (10 <= self.age <= 100):
            return False, "Age must be between 10 and 100."
        if not (20.0 <= self.weight_kg <= 300.0):
            return False, "Weight must be between 20 and 300 kg."
        if not (100.0 <= self.height_cm <= 250.0):
            return False, "Height must be between 100 and 250 cm."
        if self.gender not in VALID_GENDERS:
            return False, f"Gender must be one of {VALID_GENDERS}."
        if self.activity_level not in VALID_ACTIVITY_LEVELS:
            return False, f"Activity level must be one of {VALID_ACTIVITY_LEVELS}."
        if self.goal not in VALID_GOALS:
            return False, f"Goal must be one of {VALID_GOALS}."
        for cond in self.health_conditions:
            if cond not in VALID_CONDITIONS:
                return False, f"Unknown health condition: '{cond}'."
        return True, ""


# ---------------------------------------------------------------------------
# Meal
# ---------------------------------------------------------------------------

@dataclass
class Meal:
    """Represents a single logged meal or food item."""

    name: str
    calories: float
    protein_g: float
    carbs_g: float
    fats_g: float


# ---------------------------------------------------------------------------
# DailyLog
# ---------------------------------------------------------------------------

@dataclass
class DailyLog:
    """Holds all meals logged for the current day."""

    meals: List[Meal] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Computed totals (properties so they are always up to date)
    # ------------------------------------------------------------------

    @property
    def total_calories(self) -> float:
        return round(sum(m.calories for m in self.meals), 2)

    @property
    def total_protein_g(self) -> float:
        return round(sum(m.protein_g for m in self.meals), 2)

    @property
    def total_carbs_g(self) -> float:
        return round(sum(m.carbs_g for m in self.meals), 2)

    @property
    def total_fats_g(self) -> float:
        return round(sum(m.fats_g for m in self.meals), 2)
