"""Custom exception hierarchy for the Healthy Diet Management App."""


class DietAppError(Exception):
    """Base exception for all application errors."""
    pass


class InvalidProfileError(DietAppError):
    """Raised when user profile data fails validation."""
    pass


class InvalidMealDataError(DietAppError):
    """Raised when meal nutritional data is invalid."""
    pass


class InvalidGoalError(DietAppError):
    """Raised when an unrecognised goal string is provided."""
    pass


class InvalidConditionError(DietAppError):
    """Raised when an unrecognised health condition string is provided."""
    pass
