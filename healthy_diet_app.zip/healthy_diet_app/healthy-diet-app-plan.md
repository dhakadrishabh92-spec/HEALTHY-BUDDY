# Healthy Diet Management App — Implementation Plan

## Overview

A beginner-friendly, single-user, session-based diet management web app built with
Python and Streamlit. The app calculates daily calorie targets using the Mifflin-St
Jeor BMR formula, applies macro splits based on the user's goal, enforces
health-condition dietary rules, suggests a simple rule-based daily meal plan, and
lets users log meals and track intake vs target — all within one Streamlit session.

**Scope:** Rule-based logic only. No ML/AI models, no user authentication, no
multi-day persistence beyond session state. Data saved to a local JSON file for
within-session durability only.

**Non-Goals:**
- Multi-day historical tracking
- User accounts or login
- Real nutrition database integration
- Imperial unit support (metric only: kg / cm)

---

## Module Structure

```
healthy_diet_app/
├── app.py                  # Streamlit UI — entry point only, no business logic
├── models.py               # Data classes: UserProfile, Meal, DailyLog
├── calculator.py           # BMR, TDEE, target calories, macro breakdown
├── diet_advisor.py         # Health condition rules, tips, safe/avoid food lists
├── meal_plan.py            # Rule-based daily meal plan generator
├── meal_tracker.py         # Add/remove meals, compute daily totals
├── storage.py              # Load/save session data to a local JSON file
├── exceptions.py           # Custom exception hierarchy
└── tests/
    ├── test_calculator.py
    ├── test_diet_advisor.py
    ├── test_meal_tracker.py
    └── test_meal_plan.py
```

**Key principle:** `app.py` only calls functions from the other modules. All
calculations, rules, and data handling live in the pure-Python modules so they can
be unit-tested without Streamlit.

---

## Class / Data Model Hierarchy

```
DietAppError (base exception)
  ├── InvalidProfileError
  ├── InvalidMealDataError
  └── InvalidGoalError

UserProfile (dataclass)
  - age: int
  - gender: str           # "Male" | "Female"
  - weight_kg: float
  - height_cm: float
  - activity_level: str   # one of 5 defined levels
  - goal: str             # "Fat Cutting" | "Bulking"
  - health_condition: str # "Diabetes" | "Hypertension" | "PCOS" | "Celiac" | "None"

Meal (dataclass)
  - name: str
  - calories: float
  - protein_g: float
  - carbs_g: float
  - fats_g: float

DailyLog (dataclass)
  - meals: list[Meal]
  - total_calories: float  # computed property
  - total_protein_g: float # computed property
  - total_carbs_g: float   # computed property
  - total_fats_g: float    # computed property
```

---

## Calorie Calculation Logic

### BMR — Mifflin-St Jeor Equation
- Male:   BMR = (10 × weight_kg) + (6.25 × height_cm) − (5 × age) + 5
- Female: BMR = (10 × weight_kg) + (6.25 × height_cm) − (5 × age) − 161

### TDEE — Activity Multipliers
| Level              | Multiplier |
|--------------------|------------|
| Sedentary          | 1.2        |
| Lightly Active     | 1.375      |
| Moderately Active  | 1.55       |
| Very Active        | 1.725      |
| Extra Active       | 1.9        |

### Goal Adjustment
| Goal        | Adjustment       |
|-------------|------------------|
| Fat Cutting | TDEE − 500 kcal  |
| Bulking     | TDEE + 400 kcal  |

### Minimum Calorie Floor (Safety Rule)
- Female: floor = 1200 kcal
- Male:   floor = 1500 kcal
- If calculated target < floor, clamp to floor and surface a warning.

---

## Macro Split Rules

### Fat Cutting
| Macro   | % of Target | kcal/g |
|---------|-------------|--------|
| Protein | 40%         | 4      |
| Carbs   | 30%         | 4      |
| Fats    | 30%         | 9      |

### Bulking
| Macro   | % of Target | kcal/g |
|---------|-------------|--------|
| Protein | 30%         | 4      |
| Carbs   | 50%         | 4      |
| Fats    | 20%         | 9      |

Grams = (target_calories × macro_pct) / kcal_per_gram

---

## Health Condition Rules

Each condition produces three lists: **avoid**, **prefer**, and **tips**.

### Diabetes
- Avoid: sugary drinks, white rice, white bread, candy, pastries, fruit juice
- Prefer: leafy greens, legumes, whole grains, nuts, berries, lean proteins
- Tips: choose low-GI foods, eat smaller frequent meals, control portion sizes

### Hypertension
- Avoid: table salt, processed meats, canned soups, pickles, fast food
- Prefer: potassium-rich foods (banana, spinach), oats, garlic, olive oil
- Tips: limit sodium to under 1500 mg/day, avoid alcohol, stay hydrated

### PCOS
- Avoid: refined carbs, sugary snacks, trans fats, dairy excess
- Prefer: anti-inflammatory foods (turmeric, berries), high-fiber veg, lean protein
- Tips: eat low-GI foods, maintain stable blood sugar, include omega-3s

### Celiac
- Avoid: wheat, barley, rye, regular oats, semolina, spelt (anything with gluten)
- Prefer: rice, quinoa, corn, potatoes, certified gluten-free oats, legumes
- Tips: always check labels, avoid cross-contamination, supplement vitamins B/D/iron

### None
- No restrictions
- Generic tips: stay hydrated, eat a variety of whole foods, limit ultra-processed foods

---

## Meal Suggestion Logic (Rule-Based Only)

The meal plan generator maps (goal, health_condition) to a fixed template dictionary.
No randomness or ML required. Each template has 4 slots: Breakfast, Lunch, Dinner,
Snack.

**Decision Flow:**
1. Start with a base template for the goal (Cutting or Bulking).
2. Override or filter meals that conflict with the health condition restrictions.
3. Return the final template as a plain Python dictionary.

**Example templates (simplified):**

- Cutting + None → oats / grilled chicken salad / baked fish + veg / boiled eggs
- Cutting + Diabetes → same but swap oats for low-GI muesli, remove fruit juice
- Bulking + None → oats + banana / rice + chicken / pasta + beef / peanut butter toast
- Bulking + Celiac → swap pasta for rice noodles, swap toast for GF bread

Total templates needed: 2 goals × 5 conditions = 10 template dictionaries.

---

## Data Storage Approach

A single JSON file (`diet_session.json`) in the project root stores the current session.

**Schema:**
```json
{
  "profile": { ... UserProfile fields ... },
  "meals": [ { ... Meal fields ... }, ... ]
}
```

**Behaviour:**
- On app start, `storage.py` tries to load the file; if missing/corrupt, starts fresh.
- On every profile save or meal add/remove, the file is overwritten.
- No database, no cloud storage, no migration logic required.

---

## Streamlit Page Structure (Single Page, Sectioned)

The app uses a single `app.py` with logical sections separated by `st.expander` or
`st.tabs`. Streamlit session state (`st.session_state`) holds the live profile and
meal log between interactions.

### Section Layout

```
┌─────────────────────────────────────────┐
│  🥗  Healthy Diet Management App         │
├─────────────────────────────────────────┤
│  📋  Section 1: Personal Profile         │
│      age, gender, weight, height,        │
│      activity level, goal, condition     │
│      [ Save Profile ] button             │
├─────────────────────────────────────────┤
│  🔥  Section 2: Your Daily Targets       │
│      BMR / TDEE / Target Calories        │
│      Macro breakdown table               │
├─────────────────────────────────────────┤
│  ➕  Section 3: Log a Meal               │
│      name, calories, protein, carbs,     │
│      fats inputs + [ Add Meal ] button   │
├─────────────────────────────────────────┤
│  📊  Section 4: Today's Intake           │
│      Table of logged meals               │
│      Progress bars vs target             │
│      Remaining calories indicator        │
├─────────────────────────────────────────┤
│  🥦  Section 5: Diet Advice              │
│      Foods to avoid / prefer             │
│      Health condition tips               │
├─────────────────────────────────────────┤
│  🍽️  Section 6: Suggested Meal Plan      │
│      Breakfast / Lunch / Dinner / Snack  │
└─────────────────────────────────────────┘
```

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffold & Exceptions

**Intent:** Create the folder structure, empty module files, and the exception
hierarchy. Establishes the skeleton every other sub-task builds on.

**Expected Outcomes:**
- `healthy_diet_app/` directory exists with all listed files (empty or stub only)
- `exceptions.py` contains `DietAppError`, `InvalidProfileError`,
  `InvalidMealDataError`, `InvalidGoalError`
- `requirements.txt` lists `streamlit` and `pytest`

**Todo List:**
- [ ] Create `healthy_diet_app/` folder and all module files (empty)
- [ ] Create `tests/` subfolder with empty test files
- [ ] Write `exceptions.py` with the three custom exception classes
- [ ] Write `requirements.txt`

**Relevant Context:** No existing codebase. Follow the module structure table above.

**Status:** [ ] pending

---

### Sub-Task 2 — Data Models

**Intent:** Define `UserProfile`, `Meal`, and `DailyLog` as Python dataclasses in
`models.py`. These are pure data containers — no logic.

**Expected Outcomes:**
- All three dataclasses exist with correct typed fields
- `DailyLog` has computed properties for totals
- No circular imports

**Todo List:**
- [ ] Write `UserProfile` dataclass with all 7 fields
- [ ] Write `Meal` dataclass with all 5 fields
- [ ] Write `DailyLog` dataclass with `meals` list and four computed total properties

**Relevant Context:** See "Class / Data Model Hierarchy" section above.

**Status:** [ ] pending

---

### Sub-Task 3 — Calorie Calculator

**Intent:** Implement `calculator.py` with the four pure functions for BMR, TDEE,
target calories, and macro breakdown. No Streamlit dependency.

**Expected Outcomes:**
- `calculate_bmr(profile)` returns correct float for male and female
- `calculate_tdee(bmr, activity_level)` applies correct multiplier
- `calculate_target_calories(tdee, goal, gender)` applies deficit/surplus and clamps
  to safe minimum, returning both the value and a `clamped: bool` flag
- `calculate_macros(target_calories, goal)` returns dict with protein_g, carbs_g,
  fats_g as rounded floats

**Todo List:**
- [ ] Implement `calculate_bmr`
- [ ] Implement `calculate_tdee` with activity multiplier lookup dict
- [ ] Implement `calculate_target_calories` with floor clamping
- [ ] Implement `calculate_macros` with the two macro split tables
- [ ] Raise `InvalidGoalError` for unknown goal strings

**Relevant Context:** Formulas and tables defined in "Calorie Calculation Logic" and
"Macro Split Rules" sections above.

**Status:** [ ] pending

---

### Sub-Task 4 — Diet Advisor

**Intent:** Implement `diet_advisor.py` with rule-based lookup functions for each
health condition. All data is stored as plain Python dicts/lists — no external DB.

**Expected Outcomes:**
- `get_restrictions(condition)` returns dict with keys: `avoid`, `prefer`, `tips`
- `get_safe_foods(condition)` returns a flat list of preferred food strings
- All five conditions covered: Diabetes, Hypertension, PCOS, Celiac, None
- Raises `InvalidConditionError` for unknown condition strings

**Todo List:**
- [ ] Define the five condition data dictionaries at module level
- [ ] Implement `get_restrictions(condition)`
- [ ] Implement `get_safe_foods(condition)`
- [ ] Add input guard raising `InvalidConditionError`

**Relevant Context:** See "Health Condition Rules" section above.

**Status:** [ ] pending

---

### Sub-Task 5 — Meal Tracker

**Intent:** Implement `meal_tracker.py` to manage a list of `Meal` objects in a
`DailyLog` and expose add/remove/total operations.

**Expected Outcomes:**
- `add_meal(log, meal)` appends a validated `Meal` to `DailyLog.meals`
- `remove_meal(log, index)` removes by index safely
- `get_totals(log)` returns a dict of summed calories/protein/carbs/fats
- `get_remaining(log, target_calories)` returns `target_calories − total_calories`
- Raises `InvalidMealDataError` for negative or out-of-range nutritional values

**Todo List:**
- [ ] Implement `add_meal` with validation
- [ ] Implement `remove_meal` with bounds check
- [ ] Implement `get_totals`
- [ ] Implement `get_remaining`

**Relevant Context:** See "Data Model" and "Input Validation Rules" from analysis.
Validation limits: calories 0–5000, macros 0–500g per meal.

**Status:** [ ] pending

---

### Sub-Task 6 — Meal Plan Generator

**Intent:** Implement `meal_plan.py` with 10 fixed template dictionaries (2 goals × 5
conditions) and a single `generate_plan` function that selects the right one.

**Expected Outcomes:**
- `generate_plan(goal, condition)` returns a dict with keys: `Breakfast`, `Lunch`,
  `Dinner`, `Snack` — each a plain string description
- All 10 goal+condition combinations are covered
- Function raises `InvalidGoalError` or `InvalidConditionError` for unknown inputs

**Todo List:**
- [ ] Write 10 meal plan template dicts at module level
- [ ] Implement `generate_plan(goal, condition)` with lookup logic
- [ ] Add input guards for unknown goal or condition

**Relevant Context:** See "Meal Suggestion Logic" section above for example templates.

**Status:** [ ] pending

---

### Sub-Task 7 — JSON Storage

**Intent:** Implement `storage.py` with two functions: load and save. Serialises
`UserProfile` + list of `Meal` objects to/from `diet_session.json`.

**Expected Outcomes:**
- `save_session(profile, meals)` writes valid JSON to `diet_session.json`
- `load_session()` returns `(UserProfile, list[Meal])` or `(None, [])` if file is
  missing or corrupt
- No crash if JSON file is malformed — silently returns empty state

**Todo List:**
- [ ] Implement `save_session` using `dataclasses.asdict`
- [ ] Implement `load_session` with try/except around file read and JSON parse
- [ ] Reconstruct `UserProfile` and `Meal` objects from raw dicts

**Relevant Context:** See "Data Storage Approach" section above for JSON schema.

**Status:** [ ] pending

---

### Sub-Task 8 — Streamlit UI

**Intent:** Wire all modules together in `app.py` using Streamlit widgets and session
state. UI only — no logic implemented here.

**Expected Outcomes:**
- All 6 sections render correctly in sequence
- Profile save triggers recalculation and updates session state
- Meal add/remove updates the intake section live
- Progress bars show intake vs target for calories and each macro
- Diet advice and meal plan sections are populated from `diet_advisor` and
  `meal_plan` using the saved profile
- Warning banner shown when calorie target was clamped to the safe minimum

**Todo List:**
- [ ] Initialise `st.session_state` keys on first load (profile, log, targets)
- [ ] Load session from JSON on startup via `storage.load_session`
- [ ] Build Section 1: profile form with all 7 fields and Save button
- [ ] Build Section 2: calculated targets display (BMR, TDEE, Target, Macros table)
- [ ] Build Section 3: meal log form with Add button
- [ ] Build Section 4: logged meals table + progress bars + remaining calories
- [ ] Build Section 5: diet advice cards (avoid / prefer / tips)
- [ ] Build Section 6: meal plan suggestion display

**Relevant Context:** See "Streamlit Page Structure" section above. All computed
values come from `calculator.py` functions — never recalculate in `app.py` directly.

**Status:** [ ] pending

---

### Sub-Task 9 — Unit Tests

**Intent:** Write pytest test cases for the four pure-logic modules. No Streamlit
testing required at this stage.

**Expected Outcomes:**
- `test_calculator.py`: BMR male, BMR female, TDEE per level, macro split, floor clamp
- `test_diet_advisor.py`: each condition returns expected keys, unknown raises exception
- `test_meal_tracker.py`: add/remove meals, totals, remaining, invalid meal raises error
- `test_meal_plan.py`: all 10 goal+condition combos return valid dict with 4 keys

**Todo List:**
- [ ] Write `test_calculator.py` — 6 test functions
- [ ] Write `test_diet_advisor.py` — 6 test functions (one per condition + invalid)
- [ ] Write `test_meal_tracker.py` — 5 test functions
- [ ] Write `test_meal_plan.py` — 10 test functions (one per template)

**Relevant Context:** Use `pytest` only. No fixtures needed — all inputs are simple
constructor calls. See validation limits and business rules throughout this plan.

**Status:** [ ] pending

---

## Test Case Reference

### calculator.py

| Test ID  | Input                                        | Expected Output                        |
|----------|----------------------------------------------|----------------------------------------|
| CALC-01  | Male, 25y, 75kg, 175cm                       | BMR = 1776.25                          |
| CALC-02  | Female, 30y, 60kg, 165cm                     | BMR = 1383.25                          |
| CALC-03  | BMR=1800, Sedentary                          | TDEE = 2160.0                          |
| CALC-04  | BMR=1800, Very Active                        | TDEE = 3105.0                          |
| CALC-05  | TDEE=2000, Fat Cutting, Male                 | Target = 1500 (clamped), clamped=True  |
| CALC-06  | TDEE=2500, Fat Cutting, Male                 | Target = 2000, clamped=False           |
| CALC-07  | Target=2000, Bulking                         | protein_g=150, carbs_g=250, fats_g=44  |
| CALC-08  | Target=1800, Fat Cutting                     | protein_g=180, carbs_g=135, fats_g=60  |

### diet_advisor.py

| Test ID  | Input          | Expected                                  |
|----------|----------------|-------------------------------------------|
| ADV-01   | "Diabetes"     | avoid list contains "sugary drinks"       |
| ADV-02   | "Hypertension" | tips list contains sodium mention         |
| ADV-03   | "PCOS"         | prefer list contains anti-inflammatory    |
| ADV-04   | "Celiac"       | avoid list contains "wheat"               |
| ADV-05   | "None"         | avoid list is empty                       |
| ADV-06   | "Unknown"      | raises InvalidConditionError              |

### meal_tracker.py

| Test ID  | Input                                        | Expected                                |
|----------|----------------------------------------------|-----------------------------------------|
| TRK-01   | Add valid meal to empty log                  | log has 1 meal, totals updated          |
| TRK-02   | Add 2 meals, check totals                    | totals = sum of both meals              |
| TRK-03   | Remove meal at index 0                       | log is empty                            |
| TRK-04   | Remove at out-of-range index                 | raises IndexError                       |
| TRK-05   | Add meal with negative calories              | raises InvalidMealDataError             |

### meal_plan.py

| Test ID  | Input                          | Expected                                |
|----------|--------------------------------|-----------------------------------------|
| PLN-01   | "Fat Cutting", "None"          | dict has Breakfast, Lunch, Dinner, Snack|
| PLN-02   | "Bulking", "None"              | Lunch contains rice or high-carb item  |
| PLN-03   | "Fat Cutting", "Celiac"        | no wheat/gluten items in plan           |
| PLN-04   | "Bulking", "Diabetes"          | no sugary items in plan                 |
| PLN-05   | "Fat Cutting", "Unknown"       | raises InvalidConditionError            |

---

## Implementation Order

Execute sub-tasks in this exact sequence — each builds on the previous:

```
Sub-Task 1 (Scaffold)
    → Sub-Task 2 (Models)
        → Sub-Task 3 (Calculator)
        → Sub-Task 4 (Diet Advisor)
        → Sub-Task 5 (Meal Tracker)
        → Sub-Task 6 (Meal Plan)
            → Sub-Task 7 (Storage)
                → Sub-Task 8 (Streamlit UI)
                    → Sub-Task 9 (Unit Tests)
```

Sub-Tasks 3–6 are independent of each other and can be reviewed in any order, but
all four must be complete before starting Sub-Task 7.
