"""Simple JSON persistence — saves/loads the current session to a local file."""

from __future__ import annotations

import dataclasses
import json
import os
from typing import List, Optional, Tuple

from .models import DailyLog, Meal, UserProfile

_SESSION_FILE: str = os.path.join(os.path.dirname(__file__), "diet_session.json")


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

def save_session(profile: UserProfile, log: DailyLog) -> None:
    """Serialise *profile* and *log* to ``diet_session.json``.

    Overwrites the file on every call.
    """
    data = {
        "profile": dataclasses.asdict(profile),
        "meals": [dataclasses.asdict(m) for m in log.meals],
    }
    with open(_SESSION_FILE, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def load_session() -> Tuple[Optional[UserProfile], DailyLog]:
    """Load profile and meal log from ``diet_session.json``.

    Returns
    -------
    (UserProfile, DailyLog)
        The saved profile and log if the file exists and is valid.
    (None, DailyLog)
        An empty state if the file is missing or corrupt.
    """
    if not os.path.exists(_SESSION_FILE):
        return None, DailyLog()

    try:
        with open(_SESSION_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)

        profile = UserProfile(**data["profile"])
        meals = [Meal(**m) for m in data.get("meals", [])]
        return profile, DailyLog(meals=meals)

    except Exception:
        # If the file is malformed for any reason, start fresh silently.
        return None, DailyLog()


def clear_session() -> None:
    """Delete the session file if it exists."""
    if os.path.exists(_SESSION_FILE):
        os.remove(_SESSION_FILE)
